# OCD Severity Prediction

## Setting up the environment
- Recommended to use Python 3.9
- Create a virtual environment: `python -m venv env`
- Install requirements: `pip install -r requirements.txt`

## How to use?

### Model Development
- Run jupyter notebook named OCD_JN.ipynb

### Dashboard
- To run the dashboard: `streamlit run Dashboard_final.py`

### Github Repository
Please find the Github repository here: https://github.com/MathildaWendt/OCD-PREDICTORS